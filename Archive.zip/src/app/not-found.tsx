

const NotFound = () => {
    return (
        <div>
            <p>Not found....</p>
        </div>
    );
}

export default NotFound;