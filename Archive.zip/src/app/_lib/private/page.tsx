export default function Private(){
    return <h3>Private</h3>
}