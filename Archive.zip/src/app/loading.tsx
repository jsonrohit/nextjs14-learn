import { Suspense } from 'react';

const Loading = () => {
    return (
        <div>
            <p>Loading weather...</p>
        </div>
    );
}

export default Loading;
